<h1 align="center">Skill Quality Checker</h1>

<p align="center">Automated quality assessment for AI skills — evaluates installed skills across 5 dimensions and generates a scored report with actionable improvement suggestions.</p>

<p align="center">Last updated: 2026-05 | <a href="./README.md">中文</a></p>

## Table of Contents

- [✨ Features](#features)
- [🚀 Quick Start](#quick-start)
- [📊 Scoring Dimensions](#scoring-dimensions-100-pts-total)
- [🏅 Rating Scale](#rating-scale)
- [📋 Sample Report](#sample-report)
- [📖 Detailed Scoring Criteria](#detailed-scoring-criteria)
- [🗂 Repository Structure](#repository-structure)
- [⚠️ Notes](#notes)
- [🤖 Use as a Skill](#use-as-a-skill)
- [📄 License](#license)

## Features

- ✅ **5-Dimension Scoring**: Problem-solution fit, completeness, error handling, description precision, token efficiency
- ✅ **Fully Automated**: One command scans all skills with no manual intervention
- ✅ **Rich Reports**: Markdown / JSON output with detailed per-skill improvement notes
- ✅ **Zero Dependencies**: Pure Python standard library — nothing to install

## Quick Start

### Scan all skills

```bash
python3 scripts/check_quality.py --scan-dir ~/.claude/skills/
```

### Evaluate a single skill

```bash
python3 scripts/check_quality.py --skill ~/.claude/skills/my-skill/
```

### Save output to file

```bash
# Markdown format
python3 scripts/check_quality.py --scan-dir ~/.claude/skills/ --format markdown --output report.md

# JSON format
python3 scripts/check_quality.py --scan-dir ~/.claude/skills/ --format json --output report.json
```

## Scoring Dimensions (100 pts total)

| Dimension | Points | What's Checked |
|-----------|--------|----------------|
| Problem-Solution Fit | 20 | Does the implementation match the task type? |
| Completeness | 20 | File integrity, format conventions, no TODOs |
| Error Handling | 20 | Exception handling, fallback mechanisms |
| Description Precision | 20 | Trigger word coverage, appropriate length, not over-generalized |
| Token Efficiency | 20 | File size, progressive disclosure |

## Rating Scale

| Rating | Score Range | Label |
|--------|-------------|-------|
| ⭐⭐⭐⭐⭐ | 90–100 | Excellent |
| ⭐⭐⭐⭐ | 75–89 | Good |
| ⭐⭐⭐ | 60–74 | Acceptable |
| ⭐⭐ | 40–59 | Poor |
| ⭐ | 0–39 | Very Poor |

## Sample Report

```markdown
# 🔍 Skills Quality Review Report
Date: 2026-03-06 19:09
Scanned: 3 skills

## 📊 Summary Scores

| # | Skill | Fit | Complete | Errors | Precision | Efficiency | Total | Rating |
|---|-------|-----|----------|--------|-----------|------------|-------|--------|
| 1 | pdf-editor | 19 | 18 | 16 | 18 | 17 | 88 | ⭐⭐⭐⭐ |
| 2 | docx | 18 | 16 | 14 | 15 | 15 | 78 | ⭐⭐⭐⭐ |
| 3 | my-skill | 14 | 12 | 8 | 10 | 10 | 54 | ⭐⭐ |

## 📝 Individual Reviews

### pdf-editor — 88 pts ⭐⭐⭐⭐
- Fit 19/20: Execution-type task with scripts/ directory — good match
- Completeness 18/20: YAML frontmatter complete; 3 non-empty script files
- Error handling 16/20: Error coverage ~75%
- Precision 18/20: Appropriate length, includes bilingual trigger words
- Efficiency 17/20: SKILL.md 4.2KB, uses external reference files
```

## Detailed Scoring Criteria

See [references/scoring-criteria.md](references/scoring-criteria.md) for:

- Detailed scoring rules per dimension
- Deduction explanations
- Annotated examples

## Repository Structure

```
skill-quality-checker/
├── SKILL.md                    # Skill definition file
├── scripts/
│   └── check_quality.py        # Quality assessment script
└── references/
    └── scoring-criteria.md     # Detailed scoring criteria
```

## Notes

- Uses only Python standard library — no pip installs required
- Scores are heuristic static analysis; treat as guidance, not a substitute for human review
- If the scan directory doesn't exist or is empty, the script will report clearly

## Use as a Skill

This tool is packaged as a Skill and can be used directly after download:

```
Check quality of my-skill
Evaluate all skills
Generate skill quality report
```

## License

[MIT License](LICENSE)
